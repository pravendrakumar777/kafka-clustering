package com.pkr.service.impl;

import com.pkr.config.ConfigChannel;
import com.pkr.dto.UserDTO;
import com.pkr.exceptions.UserNotFoundException;
import com.pkr.model.User;
import com.pkr.payload.UserRequest;
import com.pkr.repository.UserRepository;
import com.pkr.service.UserService;
import com.pkr.utils.DateUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.messaging.MessageChannel;
import org.springframework.messaging.support.MessageBuilder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Service
@Transactional
public class UserServiceImpl implements UserService {

    private static final Logger log = LoggerFactory.getLogger(UserServiceImpl.class);
    private final UserRepository userRepository;
    private final ConfigChannel bindingChannel;

    public UserServiceImpl(UserRepository userRepository, ConfigChannel bindingChannel) {
        this.userRepository = userRepository;
        this.bindingChannel = bindingChannel;
    }

    @Override
    public User saveUser(UserRequest userRequest) {
        log.info("Service Request to saveUser: {}", userRequest);
        User user = new User();
        user.setName(userRequest.getName());
        user.setEmail(userRequest.getEmail());
        Timestamp timestamp = new Timestamp(System.currentTimeMillis());
        user.setCreatedDate(timestamp);
        user.setMobile(userRequest.getMobile());
        user.setStatus(userRequest.getStatus());
        user.setGender(userRequest.getGender());
        User result = userRepository.save(user);
        MessageChannel userOutputMessageChannel = bindingChannel.userDetailsOutput();
        userOutputMessageChannel.send(MessageBuilder.withPayload(result).build());
        return user;
    }

    @Override
    public List<User> fetchUsersByDateRange(String fromDate, String toDate) {
        log.info("Service Request to fetchUsersByDateRange: {}", fromDate, toDate);

        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
        Timestamp fromTimestamp;
        Timestamp toTimestamp;

        try {

            fromTimestamp = new Timestamp(dateFormat.parse(fromDate).getTime());
            toTimestamp = new Timestamp(dateFormat.parse(toDate).getTime());

            toTimestamp = new Timestamp(toTimestamp.getTime() + (24 * 60 * 60 * 1000) - 1);

            List<User> userList = userRepository.findUsersByDateRange(fromTimestamp, toTimestamp);
            for (User user : userList) {
                publishUsersDateRange(user);
            }
            return userList;
        } catch (Exception ex) {
            log.error("Error fetching users: {}", ex.getMessage());
            throw new RuntimeException("Failed to fetch users", ex);
        }
    }

    private void publishUsersDateRange(User user) {
        try {
            log.info("PUBLISHING USER LIST : {}", user);
            MessageChannel userListOutputMessageChannel = bindingChannel.userListOutput();
            userListOutputMessageChannel.send(MessageBuilder.withPayload(user).build());
        } catch (Exception ex) {
            log.error("Error Publishing user {}: {}", user.getId(), ex.getMessage());
            throw new RuntimeException("Failed to publish user", ex);
        }
    }

    @Override
    public List<UserDTO> fetchUsers() {
        log.info("Service Request to fetchUsers");
        List<User> userList = userRepository.findAll();

        List<UserDTO> processedUsers = userList.stream()
                .map(user -> {
                    UserDTO userDTO = new UserDTO();
                    userDTO.setId(user.getId());
                    userDTO.setName(user.getName());
                    userDTO.setEmail(user.getEmail());
                    userDTO.setCreatedDate(DateUtils.formatTimestamp(user.getCreatedDate()));
                    userDTO.setMobile(user.getMobile());
                    userDTO.setModifiedDate(DateUtils.formatTimestamp(user.getModifiedDate()));
                    userDTO.setStatus(user.getStatus());
                    userDTO.setGender(user.getGender());

                    return userDTO;
                })
                .collect(Collectors.toList());
        return processedUsers;
    }

    @Override
    public User findUserById(Long id) {
        return userRepository.findById(id)
                .orElseThrow(() -> new UserNotFoundException("User not found with ID: " + id));
    }

    @Override
    public User updateUser(Long id, UserRequest userRequest) {
        User existingUser = findUserById(id);
        Timestamp createdDate = existingUser.getCreatedDate();
        existingUser.setCreatedDate(createdDate);
        existingUser.setName(userRequest.getName());
        existingUser.setEmail(userRequest.getEmail());
        Timestamp timestamp = new Timestamp(System.currentTimeMillis());
        existingUser.setModifiedDate(timestamp);
        existingUser.setMobile(userRequest.getMobile());
        return userRepository.save(existingUser);
    }

    @Override
    public boolean deleteUser(Long id) {
        if (userRepository.existsById(id)) {
            userRepository.deleteById(id);
            return true;
        }
        return false;
    }

    @Override
    public List<UserDTO> fetchEnabledUsers() {
        log.info("Service Request to fetchEnabledUsers");
        return userRepository.findByStatus("Enabled").stream()
                .map(this::convertToDTO)
                .collect(Collectors.toList());
    }

    @Override
    public List<UserDTO> fetchDisabledUsers() {
        log.info("Service Request to fetchDisabledUsers");
        return userRepository.findByStatus("Disabled").stream()
                .map(this::convertToDTO)
                .collect(Collectors.toList());
    }

    private UserDTO convertToDTO(User user) {
        return new UserDTO(
                user.getId(),
                user.getName(),
                user.getEmail(),
                DateUtils.formatTimestamp(user.getCreatedDate()),
                user.getMobile(),
                DateUtils.formatTimestamp(user.getModifiedDate()),
                user.getStatus(),
                user.getGender()
        );
    }

    @Override
    public Map<String, Long> getUserCountsByStatus() {
        log.info("Service Request to getUserCountsByStatus");
        List<User> userList = userRepository.findAll();
        Map<String, Long> counts = new HashMap<>();
        for (User user : userList) {
            counts.put(user.getStatus(), counts.getOrDefault(user.getStatus(), 0L) + 1);
        }
        return counts;
    }
}
