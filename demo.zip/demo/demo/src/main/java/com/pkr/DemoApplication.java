package com.pkr;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemoApplication.class, args);
		// Swagger UI = http://localhost:8083/swagger-ui.html

		// MVC UI = http://localhost:8083/create-user
		// All operation can on single url
	}
}
