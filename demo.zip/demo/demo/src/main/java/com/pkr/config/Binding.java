package com.pkr.config;

import org.springframework.cloud.stream.annotation.EnableBinding;

@EnableBinding(ConfigChannel.class)
public class Binding {
}
