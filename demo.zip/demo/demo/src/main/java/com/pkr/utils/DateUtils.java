package com.pkr.utils;

import java.sql.Timestamp;
import java.text.SimpleDateFormat;

public class DateUtils {
    public static String formatTimestamp(Timestamp timestamp) {
        if (timestamp != null) {
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
            return sdf.format(timestamp);
        }
        return null;
    }
}
